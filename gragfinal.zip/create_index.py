from neo4j import GraphDatabase
from config import driver, DIMENSION
import sys

def create_indices():
    try:
        # Langsung menggunakan Cypher tanpa library tambahan
        with driver.session() as session:
            result = session.run("""
                CREATE VECTOR INDEX ayat_embeddings IF NOT EXISTS
                FOR (a:Ayat) 
                ON a.embedding
                OPTIONS {
                    indexConfig: {
                        `vector.dimensions`: $dim,
                        `vector.similarity_function`: 'cosine'
                    }
                }
            """, dim=DIMENSION)
            
            # Commit transaksi
            result.consume()
            
            # Verifikasi index
            check = session.run("""
                SHOW INDEXES 
                WHERE name = 'ayat_embeddings' 
                AND type = 'VECTOR'
            """)
            
            if check.single():
                print("✅ Index vektor berhasil dibuat")
                print("Detail Index:")
                print(f"- Nama: ayat_embeddings")
                print(f"- Tipe: VECTOR")
                print(f"- Dimensi: {DIMENSION}")
                print(f"- Similarity Function: cosine")
            else:
                print("❌ Gagal membuat index!")
                sys.exit(1)

    except Exception as e:
        print(f"❌ Error saat membuat index: {str(e)}")
        sys.exit(1)
    finally:
        driver.close()

if __name__ == "__main__":
    create_indices()