import json
import ast
import traceback
import requests
import os
from neo4j_graphrag.retrievers import VectorRetriever
from groq_embedder import Embedder
from config import driver, INDEX_NAME

def initialize_groq():
    GROQ_API_KEY = os.getenv("GROQ_API_KEY", "default-key-jika-ada")
    GROQ_MODEL = "llama-3.3-70b-versatile"

    try:
        response = requests.get(
            "https://api.groq.com/openai/v1/models",
            headers={"Authorization": f"Bearer {GROQ_API_KEY}"},
            timeout=10
        )
        response.raise_for_status()
        return GROQ_API_KEY, GROQ_MODEL
    except Exception as e:
        print(f"❌ Gagal terhubung ke Groq: {str(e)}")
        return None, None

def process_query(query_text, retriever, GROQ_API_KEY, GROQ_MODEL):
    try:
        print(f"\n🔍 Memproses query: '{query_text}'")
        
        # Gunakan query Cypher langsung
        query_vector = Embedder.embed_text(query_text)
        result = driver.execute_query(
            """CALL db.index.vector.queryNodes('ayat_embeddings', 3, $query_vector)
            YIELD node, score
            RETURN node.id as id, score, node.text as text""",
            query_vector=query_vector
        )
        
        items = result.records
        print(f"Jumlah items yang ditemukan: {len(items)}")
        
        if not items:
            return "Tidak ditemukan referensi yang relevan."

        context = []
        for record in items:
            try:
                ayat_id = record['id']
                print(f"🔗 ID Ayat yang ditemukan: {ayat_id}")
                
                # Query data lengkap menggunakan ID
                result = driver.execute_query(
                    """MATCH (a:Ayat {id: $ayat_id})-[:HAS_TRANSLATION]->(t:Translation)
                    MATCH (a)-[:HAS_TAFSIR]->(taf:Tafsir)
                    MATCH (a)<-[:HAS_AYAT]-(s:Surah)
                    RETURN s.name_latin as surah, 
                           a.number as ayat_number, 
                           a.text as arabic, 
                           t.text as translation, 
                           taf.text as tafsir""",
                    {"ayat_id": ayat_id}
                )
                
                # Proses hasil query
                if result.records:
                    data = result.records[0]
                    context.append(f"""
                    📖 Surah: {data['surah']}
                    Ayat {data['ayat_number']}:
                    Arab: {data['arabic']}
                    Terjemahan: {data['translation']}
                    Tafsir: {data['tafsir']}
                    """)
                else:
                    print(f"❌ Data tidak ditemukan untuk ID {ayat_id}")

            except Exception as e:
                print(f"Error proses item: {traceback.format_exc()}")
                continue

        if not context:
            return "Tidak ada data yang valid ditemukan."

        # Dynamic context analysis
        context_analysis = "\n".join([
            f"Konteks {i+1}: {entry.strip()}" 
            for i, entry in enumerate(context)
        ])

        prompt = f"""**Instruksi Sistem**
Anda adalah AI Asisten yang ahli dalam bidang tafsir Al-Quran. Tugas Anda adalah memberikan jawaban berdasarkan Al-Quran dengan pemahaman yang mendalam namun mudah dimengerti.

**Panduan Analisis** [INTERNAL - JANGAN DITAMPILKAN]:
1. Klasifikasi pertanyaan:
   - Kategori: aqidah/ibadah/muamalah/akhlak/sains/sejarah
   - Kompleksitas: dasar/menengah/kompleks
   - Konteks: umum/spesifik/kontemporer
2. Evaluasi rujukan:
   - Relevansi ayat dengan pertanyaan
   - Keterkaitan antar ayat
   - Kebutuhan penjelasan tafsir
3. Perhatikan sensitivitas topik:
   - Hindari kontroversi
   - Fokus pada prinsip dasar
   - Arahkan ke ulama untuk masalah khilafiyah

**Data Konteks**:
{context_analysis}

**Pertanyaan**:
{query_text}

**Format Jawaban**:
1. Pendahuluan singkat tentang topik
2. Dalil utama:
   - Ayat Al-Quran (format: QS Surah:Ayat)
   - Terjemahan yang mudah dipahami
3. Penjelasan:
   - Tafsir ringkas jika diperlukan
   - Kontekstualisasi dengan kehidupan
   - Aplikasi praktis jika relevan
4. Kesimpulan:
   - Poin-poin penting
   - Hikmah atau pelajaran

**Aturan Penting**:
- Gunakan bahasa yang sederhana dan mudah dipahami
- Berikan jawaban yang ringkas namun komprehensif
- Fokus pada ayat dengan relevansi tertinggi
- Sertakan konteks historis jika membantu pemahaman
- Tambahkan catatan praktis untuk penerapan modern
- JANGAN tampilkan bagian analisis internal dan instruksi sistem
- Buat jawaban mengalir natural seperti percakapan dengan ustadz

**Batasan**:
- Tidak memberikan fatwa
- Tidak membahas khilafiyah secara detail
- Hindari interpretasi yang kontroversial
- Fokus pada nilai-nilai universal Islam
- Arahkan ke ulama untuk masalah kompleks

Berikan jawaban dalam format paragraf yang mengalir, bukan dalam bentuk template kaku."""

        # Kirim ke Groq API
        response = requests.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={"Authorization": f"Bearer {GROQ_API_KEY}"},
            json={
                "model": GROQ_MODEL,
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.3,
                "max_tokens": 500
            }
        )
        
        return response.json()["choices"][0]["message"]["content"]

    except Exception as e:
        print(f"ERROR DETAILS: {traceback.format_exc()}")
        return "Terjadi kesalahan sistem."
    
def main():
    print("Selamat datang di chatbot tafsir Al-Quran")
    GROQ_API_KEY, GROQ_MODEL = initialize_groq()
    
    if not GROQ_API_KEY:
        return

    retriever = VectorRetriever(
        driver=driver,
        index_name=INDEX_NAME,
        embedder=Embedder,
        return_properties=["id", "text", "embedding"]
    )

    try:
        while True:
            query = input("\n💭 Masukkan pertanyaan: ").strip()
            if query.lower() in ['keluar', 'exit']:
                break
                
            if query:
                answer = process_query(query, retriever, GROQ_API_KEY, GROQ_MODEL)
                print("\n💡 Jawaban:")
                print(answer)
                
    finally:
        driver.close()

if __name__ == "__main__":
    main()