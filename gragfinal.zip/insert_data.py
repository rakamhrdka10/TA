import json
from neo4j import GraphDatabase
from tqdm import tqdm
from config import driver
from groq_embedder import Embedder

def validate_embedding(vector):
    if not isinstance(vector, list):
        raise ValueError("Embedding harus berupa list")
    if len(vector) != 384:  
        raise ValueError(f"Dimensi embedding salah: {len(vector)}")
    if all(v == 0 for v in vector):
        raise ValueError("Embedding tidak valid (all zeros)")

def insert_quran_data():
    with open("quran.json", "r", encoding="utf-8") as file:
        quran_data = json.load(file)

    try:
        with driver.session() as session:
            session.run("MATCH (n) DETACH DELETE n")

            total_ayat = sum(len(surah["text"]) for surah in quran_data)
            progress_bar = tqdm(total=total_ayat, desc="Memproses Ayat")

            for surah in quran_data:
                surah_id = surah["_id"]["$oid"]
                surah_name = surah["name_latin"]
                
                # Create Surah node
                session.run(
                    "MERGE (s:Surah {id: $id}) SET s += $properties",
                    {"id": surah_id, "properties": {
                        "name_latin": surah_name,
                        "number_of_ayat": len(surah["text"])
                    }}
                )

                # Process Ayat
                for ayah_num, ayah_text in surah["text"].items():
                    translation = surah["translations"]["id"]["text"].get(ayah_num, "")
                    tafsir = surah["tafsir"]["id"]["kemenag"]["text"].get(ayah_num, "")

                    # Generate embedding dengan validasi
                    combined_text = f"Surah {surah_name} Ayat {ayah_num}: {ayah_text} {translation} {tafsir}"
                    try:
                        vector = Embedder.embed_text(combined_text)
                        validate_embedding(vector)
                    except Exception as e:
                        print(f"Error di Surah {surah_name} Ayat {ayah_num}: {str(e)}")
                        continue

                    # Create Ayat node
                    session.execute_write(lambda tx: tx.run(
                        """MATCH (s:Surah {id: $surah_id})
                        CREATE (a:Ayat {
                            id: $ayat_id,
                            number: $number,
                            text: $text,
                            embedding: $embedding
                        })
                        CREATE (a)-[:HAS_TRANSLATION]->(:Translation {text: $translation})
                        CREATE (a)-[:HAS_TAFSIR]->(:Tafsir {text: $tafsir})
                        CREATE (s)-[:HAS_AYAT]->(a)""",
                        {
                            "surah_id": surah_id,
                            "ayat_id": f"{surah_id}-{ayah_num}",
                            "number": int(ayah_num),
                            "text": ayah_text,
                            "embedding": vector,
                            "translation": translation,
                            "tafsir": tafsir
                        }
                    ))
                    progress_bar.update(1)

            progress_bar.close()
            print("✅ Data berhasil dimasukkan")

    except Exception as e:
        print(f"❌ Error: {str(e)}")
    finally:
        driver.close()

if __name__ == "__main__":
    insert_quran_data()